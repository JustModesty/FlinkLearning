package org.jjjsdkpkg;

/**
 * Hello world!
 */
public class JJJUtils {
    public String getHappyName(String name) {
        System.out.println("jjj debug, JJJUtils. name: " + name);
        return "getHappyName_" + name;
    }
}
