package org.whatever;

import org.apache.flink.api.common.JobExecutionResult;
import org.apache.flink.streaming.api.datastream.DataStreamSink;
import org.apache.flink.streaming.api.datastream.DataStreamSource;
import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.jjjsdkpkg.JJJUtils;


/**
 * Hello world!
 */
public class AppGraphEntry {
    public static void main(String[] args) throws Exception {
        // todo 1. 创建执行环境
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        // todo 2. 读取数据 socket
        DataStreamSource<String> socketDS = env.socketTextStream("192.168.137.20", 7777);
        // todo 3. 处理数据
        SingleOutputStreamOperator<Integer> sum = socketDS.map(Integer::valueOf).keyBy(value -> value).sum(0);
        String xiaoMing = new JJJUtils().getHappyName("XiaoMing");
        System.out.println("jjj debug, xiaoMing: " + xiaoMing);
        // todo 4. 输出
        DataStreamSink<Integer> print = sum.print();
        // todo 5. 执行
        JobExecutionResult execute = env.execute();
    }
}