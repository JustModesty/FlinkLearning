package org.whatever;

import org.apache.flink.api.common.JobID;
import org.apache.flink.client.deployment.StandaloneClusterId;
import org.apache.flink.client.program.PackagedProgram;
import org.apache.flink.client.program.PackagedProgramUtils;
import org.apache.flink.client.program.rest.RestClusterClient;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.configuration.JobManagerOptions;
import org.apache.flink.configuration.RestOptions;
import org.apache.flink.runtime.jobgraph.JobGraph;

import java.io.File;
import java.net.URI;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

/**
 * Hello world!
 */
public class AppClient {
    public static void main(String[] args) throws Exception {
        // 集群信息
        Configuration configuration = new Configuration();
        configuration.setString(JobManagerOptions.ADDRESS, "192.168.137.20");
        configuration.setInteger(JobManagerOptions.PORT, 6123);
        configuration.setInteger(RestOptions.PORT, 8081);
        RestClusterClient<StandaloneClusterId> restClusterClient = new RestClusterClient<StandaloneClusterId>(configuration, StandaloneClusterId.getInstance());
        String arg = args[0];
        if ("submit".equals(arg)) {
            submit(restClusterClient, configuration);
        } else if ("cancel".equals(arg)) {
            String jobId = args[1];
            cancel(restClusterClient, jobId);
        } else if ("status".equals(arg)) {
            String jobId = args[1];
            getJobStatus(restClusterClient, jobId);
        } else {
            System.out.println("do nothing....");
        }
    }

    public static String submit(RestClusterClient<StandaloneClusterId> restClusterClient, Configuration flinkConfiguration) throws Exception {

        String flinkJarPath = "/opt/mateinfo/GASFlinkService/flink-graph-entry-1.0-SNAPSHOT.jar";

        PackagedProgram packagedProgram = PackagedProgram.newBuilder().setJarFile(new File(flinkJarPath)) //.setArguments(arguments)
                .build();
        JobGraph jobGraph = PackagedProgramUtils.createJobGraph(packagedProgram, flinkConfiguration, 1, false);
        JobID jobID = null;
        jobID = restClusterClient.submitJob(jobGraph).get();
//        try (RestClusterClient<StandaloneClusterId> client = new RestClusterClient<>(flinkConfiguration, StandaloneClusterId.getInstance())) {
//            jobID = client.submitJob(jobGraph).get();
//        }
        System.out.println("submit, res jobID: " + jobID);
        return jobID.toString();
    }

    //取消任务
    public static String submit2(RestClusterClient<StandaloneClusterId> restClusterClient) throws Exception {


        //提交任务, jarpath 是项目jar包地址

//        StreamGraph streamGraph = env.getStreamGraph();
//        streamGraph.setJobName("zxy0510—test");
        JobGraph jobGroup = new JobGraph("zxy0510—test");

        List<URL> urls = new ArrayList<>();

        String jarpath = "ftp://localhost/opt/mateinfo/GASFlinkService/flink-graph-entry-1.0-SNAPSHOT.jar";
        String flinkJarPath = "/opt/mateinfo/GASFlinkService/flink-graph-entry-1.0-SNAPSHOT.jar";
//        URL url = new URL("ftp", "localhost", "/opt/mateinfo/GASFlinkService/flink-graph-entry-1.0-SNAPSHOT.jar");

        File file = new File(flinkJarPath);
        URI uri = file.toURI();
        URL url = uri.toURL();
        System.out.println("jjj debug, url: " + url);
//        URL url = file.toURL();
//        URL url = new URL(jarpath);
        urls.add(url);
//        JobGraph jobGroup = streamGraph.getJobGraph();

        ;

        jobGroup.addJars(urls);
        System.out.println("jjj debug, jobGroup: " + jobGroup);

        //分离模式
//        CompletableFuture<JobID> aa = restClusterClient.submitJob(jobGroup);
        CompletableFuture<JobID> jobIDCompletableFuture = restClusterClient.submitJob(jobGroup);
        System.out.println("jjj debug, jobIDCompletableFuture: " + jobIDCompletableFuture);
        Thread.sleep(5000);
        JobID jobId = jobIDCompletableFuture.get();
        System.out.println("submit, res jobId: " + jobId);
        return jobId.toString();
    }


    //取消任务
    public static String cancel(RestClusterClient<StandaloneClusterId> restClusterClient, String jobId) throws Exception {
        CompletableFuture<String> respstatus = restClusterClient.cancel(new JobID().fromHexString(jobId)).thenApply(kl -> {
            return kl.toString();
        });
        String res = respstatus.get();
        System.out.println("cancel, res: " + res);
        return res;
    }

    //查看任务状态
    public static String getJobStatus(RestClusterClient<StandaloneClusterId> restClusterClient, String jobId) throws InterruptedException, ExecutionException {
        CompletableFuture<String> status = restClusterClient.getJobStatus(new JobID().fromHexString(jobId)).thenApply(v -> {
            return v.name();
        });
        String res = status.get();
        System.out.println("getJobStatus, res: " + res);
        return res;
    }
}
